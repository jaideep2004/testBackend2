<?php
/*
Plugin Name: Custom Registration Form
Description: A custom registration form for a trucking company.
Version: 1.0
Author: Your Name
*/

// Register the custom styles and scripts
function crf_enqueue_scripts() {
    wp_enqueue_style('crf-style', plugin_dir_url(__FILE__) . 'style.css');
}
add_action('wp_enqueue_scripts', 'crf_enqueue_scripts');

// Shortcode to display the registration form
function crf_registration_form() {
    ob_start();
    ?>
    <div class="crf-container">
        <form id="custom-registration-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="crf_register_user">
            
            <!-- Personal Information Section -->
            <div class="crf-full-width">
                <h2>Personal Information</h2><br>
            </div>
            <div class="crf-form-field"><label>Full Name</label><input type="text" name="full_name" required></div>
            <div class="crf-form-field"><label>Social Insurance Number (SIN)</label><input type="text" name="sin" required></div>
            <div class="crf-form-field"><label>Address</label><input type="text" name="address" required></div>
            <div class="crf-form-field"><label>Telephone</label><input type="tel" name="telephone" required></div>
            <div class="crf-form-field"><label>Date of Birth</label><input type="date" name="dob" required></div>
            <div class="crf-form-field"><label>Email Address</label><input type="email" name="email" required></div>
            
            <!-- License Information Section -->
            <div class="crf-full-width">
                <h2>License Information</h2><br>
            </div>
            <div class="crf-form-field"><label>Drivers License Number</label><input type="text" name="license_number" required></div>
            <div class="crf-form-field"><label>License Class</label><input type="text" name="license_class" required></div>
            <div class="crf-form-field"><label>Province</label><input type="text" name="province" required></div>
            <div class="crf-form-field"><label>Licensed Since</label><input type="date" name="licensed_since" required></div>
            <div class="crf-form-field"><label>Expiry Date</label><input type="date" name="expiry_date" required></div>
            <div class="crf-form-field"><label>History of Suspension or Revocation</label>
                <label><input type="radio" name="suspension_history" value="yes" required> Yes</label>
                <label><input type="radio" name="suspension_history" value="no" required> No</label>
                <p>*Please disclose any history of suspension or revocation of your driver's license.</p>
            </div>

            <!-- Employment Information Section -->
            <div class="crf-full-width">
                <h2>Employment Information</h2><br>
            </div>
            <div class="crf-form-field"><label>Date of Application</label><input type="date" name="date_of_application" required></div>
            <div class="crf-form-field"><label>Date Available</label><input type="date" name="date_available" required></div>
            <div class="crf-form-field"><label>Previous Employment with Company</label>
                <label><input type="radio" name="previous_employment" value="yes" required> Yes</label>
                <label><input type="radio" name="previous_employment" value="no" required> No</label>
            </div>
            <div class="crf-form-field"><label>Moving Violations</label><textarea name="moving_violations" required></textarea>
                <p>List any moving violations you have had in the past three years.</p>
            </div>
            <div class="crf-form-field"><label>License Suspensions</label><textarea name="license_suspensions" required></textarea>
                <p>List any suspensions of your driver's license.</p>
            </div>
            <div class="crf-form-field"><label>Class 1 Driver’s License Duration</label><input type="text" name="license_duration" required></div>
            <div class="crf-form-field"><label>Legal Entitlement to Work in Canada</label>
                <label><input type="radio" name="legal_entitlement" value="yes" required> Yes</label>
                <label><input type="radio" name="legal_entitlement" value="no" required> No</label>
                <p>Are you legally entitled to work in Canada?</p>
            </div>
            <div class="crf-form-field"><label>Criminal Record</label>
                <label><input type="radio" name="criminal_record" value="yes" required> Yes</label>
                <label><input type="radio" name="criminal_record" value="no" required> No</label>
                <p>Do you have a criminal record?</p>
            </div>

            <!-- Position Applying For Section -->
            <div class="crf-full-width">
                <h2>Position Applying For</h2>
            </div>
            <div class="crf-form-field"><label>Position Applying For</label>
                <select name="position_applying_for" required>
                    <option value="owner_operator">Owner-Operator</option>
                    <option value="driver_for_owner_operator">Driver for Owner-Operator</option>
                    <option value="company_driver">Company Driver</option>
                </select>
            </div>
            <div class="crf-form-field"><label>Operation Type</label>
                <select name="operation_type" required>
                    <option value="single">Single</option>
                    <option value="team">Team</option>
                </select>
            </div>
            <div class="crf-form-field"><label>Ability to Operate in US</label>
                <label><input type="radio" name="us_operation" value="yes" required> Yes</label>
                <label><input type="radio" name="us_operation" value="no" required> No</label>
                <p>Are you able to operate in the United States?</p>
            </div>

            <!-- Education Section -->
            <div class="crf-full-width">
                <h2>Education</h2>
            </div>
            <div class="crf-form-field"><label>Highest Grade Completed</label><input type="text" name="highest_grade_completed" required></div>
            <div class="crf-form-field"><label>Trade/Technical School</label><textarea name="trade_technical_school" required></textarea>
                <p>Provide details of any trade or technical schools attended.</p>
            </div>
            <div class="crf-form-field"><label>Professional Driving Courses</label><textarea name="professional_driving_courses" required></textarea>
                <p>List any professional driving courses you have completed.</p>
            </div>

            <!-- Qualifications Section -->
            <div class="crf-full-width">
                <h2>Qualifications</h2>
            </div>
            <div class="crf-form-field"><label>Denied Driver’s License History</label>
                <label><input type="radio" name="denied_license_history" value="yes" required> Yes</label>
                <label><input type="radio" name="denied_license_history" value="no" required> No</label>
                <p>Disclose any denials, suspensions, or revocations of your driver's license.</p>
            </div>
            <div class="crf-form-field"><label>Medical Standards</label>
                <label><input type="radio" name="medical_standards" value="yes" required> Yes</label>
                <label><input type="radio" name="medical_standards" value="no" required> No</label>
                <p>Do you meet the medical standards for commercial drivers?</p>
            </div>
            <div class="crf-form-field"><label>Required Documents Upload</label>
                <input type="file" name="required_documents[]" multiple>
                <p>Upload the following documents: Driver Abstract, Criminal Record Check, FAST Card, Driver's License, Passport.</p>
            </div>

            <!-- Driving Experience Section -->
            <div class="crf-full-width">
                <h2>Driving Experience</h2>
            </div>
            <div class="crf-form-field"><label>Equipment Operation Experience</label><textarea name="equipment_experience" required></textarea>
                <p>List the types of equipment you have operated.</p>
            </div>
            <div class="crf-form-field"><label>States & Provinces Operated In</label><textarea name="states_provinces_operated" required></textarea>
                <p>List the states and provinces you have operated in.</p>
            </div>

            <!-- Emergency Contact Section -->
            <div class="crf-full-width">
                <h2>Emergency Contact</h2>
            </div>
            <div class="crf-form-field"><label>Emergency Contact Name</label><input type="text" name="emergency_contact_name" required></div>
            <div class="crf-form-field"><label>Emergency Contact Telephone</label><input type="tel" name="emergency_contact_telephone" required></div>
            <div class="crf-form-field"><label>Emergency Contact Relationship</label><input type="text" name="emergency_contact_relationship" required></div>
            <div class="crf-form-field"><label>Emergency Contact Email Address</label><input type="email" name="emergency_contact_email" required></div>
            <div class="crf-form-field"><label>Emergency Contact Address</label><input type="text" name="emergency_contact_address" required></div>

            <!-- Medical Information Section -->
            <div class="crf-full-width">
                <h2>Medical Information</h2>
            </div>
            <div class="crf-form-field"><label>Ability to Perform Job</label>
                <label><input type="radio" name="ability_to_perform_job" value="yes" required> Yes</label>
                <label><input type="radio" name="ability_to_perform_job" value="no" required> No</label>
                <p>Are you physically able to perform the duties required of a truck driver?</p>
            </div>
            <div class="crf-form-field"><label>Last Physical Examination Date</label><input type="date" name="last_physical_exam" required></div>
            <div class="crf-form-field"><label>Family Doctor Information</label><textarea name="family_doctor" required></textarea>
                <p>Provide details of your family doctor.</p>
            </div>

            <!-- Employment History Section -->
            <div class="crf-full-width">
                <h2>Employment History</h2>
            </div>
            <!-- Repeater Field for Multiple Employers -->
            <div class="crf-form-field"><label>Employer 1</label><input type="text" name="employer_1"></div>
            <div class="crf-form-field"><label>Position</label><input type="text" name="position_1"></div>
            <div class="crf-form-field"><label>From Date</label><input type="date" name="from_date_1"></div>
            <div class="crf-form-field"><label>To Date</label><input type="date" name="to_date_1"></div>
            <div class="crf-form-field"><label>Reason for Leaving</label><textarea name="reason_for_leaving_1"></textarea></div>

            <!-- Additional Employers can be added similarly -->

            <!-- Driver Disclosure Section -->
            <div class="crf-full-width">
                <h2>Driver Disclosure</h2>
            </div>
            <div class="crf-form-field"><label>License Declaration</label>
                <label><input type="checkbox" name="license_declaration" required> I hereby declare that the information provided is true and accurate to the best of my knowledge.</label>
            </div>
            <div class="crf-form-field"><label>Convictions and At-Fault Traffic Accidents</label><textarea name="convictions_accidents" required></textarea>
                <p>List any convictions or at-fault traffic accidents you have had.</p>
            </div>

            <!-- Additional Consents and Authorizations -->
            <div class="crf-full-width">
                <h2>Additional Consents and Authorizations</h2>
            </div>
            <div class="crf-form-field"><label>Drug & Alcohol Test Authorization</label>
                <label><input type="checkbox" name="drug_alcohol_test_authorization" required> I authorize Bullet Express Inc. to conduct pre-employment and periodic drug and alcohol testing.</label>
            </div>
            <div class="crf-form-field"><label>Acceptance of Safety Plan</label>
                <label><input type="checkbox" name="acceptance_of_safety_plan" required> I acknowledge receipt and understanding of the company's safety plan.</label>
            </div>
            <div class="crf-form-field"><label>Consent for FMCSA Queries</label>
                <label><input type="checkbox" name="consent_fmcsa_queries" required> I consent to Bullet Express Inc. conducting queries of the FMCSA’s Drug & Alcohol Clearinghouse.</label>
            </div>

            <!-- Submit Button -->
            <div class="crf-full-width">
                <button type="submit" class="crf-submit-button">Submit Application</button>
            </div>
        </form>
    </div>
    <?php
    return ob_get_clean();
}


add_shortcode('custom_registration_form', 'crf_registration_form');

// Handle form submission
function crf_handle_form_submission() {
    if (isset($_POST['action']) && $_POST['action'] == 'crf_register_user') {
        // Handle form data and save to database or send email
        // Add your form processing code here

        wp_redirect(home_url());
        exit;
    }
}
add_action('admin_post_nopriv_crf_register_user', 'crf_handle_form_submission');
add_action('admin_post_crf_register_user', 'crf_handle_form_submission');
